
// function give_sorted_array(){
//     const points = [40, 100, 1, 5, 25, 10]; 
//     points.sort(function(a, b){return a - b});
//     document.getElementById("Aizawa").innerHTML = points; 
// }


// sorting the array in random order: 
function give_sorted_array(){
    // const points = [40, 100, 1, 5, 25, 10];
    // points.sort(function(){return 0.5 - Math.random()});
    // document.getElementById("Aizawa").innerHTML = points; 

    // fisher yetes methood:
    const points = [40, 100, 1, 5, 25, 10];

    for (let i = points.length -1; i > 0; i--) {
        let j = Math.floor(Math.random() * (i+1));
        let k = points[i];
        points[i] = points[j];
        points[j] = k;
    }
    document.getElementById("Aizawa").innerHTML = points; 
}


// finding the highest and lowest element: 

function highest_element(){
    const points = [40, 100, 1, 5, 25, 10];
    var ans =  Math.max.apply(null, points);
    document.getElementById("Aizen").innerHTML =  ans; 
}


function lowest_element(){
    const points = [40, 100, 1, 5, 25, 10];
    var ans =  Math.min.apply(null, points);
    document.getElementById("Aizen1").innerHTML =  ans; 
}

// array iterations 

/*
JavaScript const variables must be assigned a value when they are declared:

Meaning: An array declared with const must be initialized when it is declared.

Using const without initializing the array is a syntax error:


Arrays declared with var can be initialized at any time.

You can even use the array before it is declared


Const Block Scope: 

An array declared with const has Block Scope.

An array declared in a block is not the same as an array declared outside the block:


*/ 