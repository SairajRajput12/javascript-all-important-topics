// refer html file thisPointer.html 
/*
JSON is a format for storing and transporting data.
JSON is often used when data is sent from a server to a web page.
*/


// what is JSON ?? 
/*

JSON stands for JavaScript Object Notation
JSON is a lightweight data interchange format
JSON is language independent *
JSON is "self-describing" and easy to understand
The JSON syntax is derived from JavaScript object notation syntax, but the JSON format is text only. Code for reading and generating JSON data can be written in any programming language.

// it creats javascript string into the javascript object. 

*/
// it has a built in function for converting JSON strings into the javascript object:  

// JSON.parse()

// has a built in function for converting an object into a JSON string 

// JSON.stringify() 

/*
JSON rules: 
    1] data is name/value pairs. 
    2] data is seprated by commas. 
    3] curly brackets hold objects. 
    4] square brackets hold arrays.  
    5] JSON requires double quote. 
*/

// JSON Data - A Name and a value: 
// JSON data is written as name/value pairs 
// e.g, "name":"sairaj" 
/*
In JSON, values must be one of the following data types:

a string
a number
an object
an array
a boolean
null

In JavaScript values can be all of the above, plus any other valid JavaScript expression, including:

a function
a date
undefined
*/

// JSON values cannot be one of the following data types:

// a function
// a date
// undefined

const obj = JSON.parse('{"name":"John", "age":30, "city":"New York"}') 

// here the attribute inside the parse method is data recieved from the webserver. 
console.log(obj) 

const text = '["Ford", "BMW", "Audi", "Fiat"]';
const myArr = JSON.parse(text);
console.log(myArr)

// JSON stringify: 
// it converts the javascript object into the JSON string 

const myJSON = JSON.stringify(obj); 
console.log(myJSON)
console.log(typeof(myJSON))


// storing data: 
const myObj = {name : "jhon",age:31,city:"New York"} 
const myJSON1 = JSON.stringify(myObj) 
localStorage.setItem("testJSON",myJSON1); 


// retrieving the text 
text1 = localStorage.getItem("testJSON") 
obj1 = JSON.parse(text1) 
console.log(obj1.name); 


// accessing object values: 
x = obj1.name  // or x = myObj["name"]

let text3 = ""
for (const x in obj1) {
  text3 += obj1[x] + ", ";
}

console.log(text3)
// extra comma is not tolerated in JSON

// Jquery vs javascript: 
// -> it is a javascript library. 
// findindghtml element by Id: 
// 




















 

