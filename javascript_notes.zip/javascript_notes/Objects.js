document.write("we are going to learn about Objects in javascript. ") 

/* 
JavaScript variables can be objects. Arrays are special kinds of objects.
Because of this, you can have variables of different types in the same Array
*/

// The length property is always one more than the highest array index. 
// const fruits = ["Banana", "Orange", "Apple"];
// fruits.push("Lemon");  // Adds a new element (Lemon) to fruits

// javascript primitives: 
//      A primitive value is a value that has no properties or methods.
//      A primitive data type is data that has a primitive value.
/*
Types of primitive data: 
    string
    number
    boolean
    null
    undefined
    symbol
    bigint
Primitive values are immutable (they are hardcoded and cannot be changed).
*/ 

/*
Value	    Type	                Comment
"Hello" 	string	        "Hello" is always "Hello"
3.14    	number	        3.14 is always 3.14
true    	boolean	        true is always true
false   	boolean	        false is always false
null	    null (object)	null is always null
undefined	undefined	    undefined is always undefined
*/


// JavaScript variables can also contain many values.
// Objects are variables too. But objects can contain many values.
// Object values are written as name : value pairs (name and value separated by a colon).
// A JavaScript object is a collection of named values
// It is a common practice to declare objects with the const keyword.
// The named values, in JavaScript objects, are called properties.
/*
    Methods are actions that can be performed on objects.
    Object properties can be both primitive values, other objects, and functions.
    An object method is an object property containing a function definition.
*/

// JavaScript objects are containers for named values, called properties and methods.



// creating the javascript object: 
/*
With JavaScript, you can define and create your own objects.
There are different ways to create new objects:

Create a single object, using an object literal.
Create a single object, with the keyword new.
Define an object constructor, and then create objects of the constructed type.
Create an object using Object.create().
*/


// 1] using object literal: 
// -> using object literal we can both define and create the object in single statement.  
// -> an object literal is considered as a list of key and pair values. 
// -> Objects created using object literal are singletons, this means when a change is made to the object, it affects the object entire the script. Whereas if an object is created using constructor function and a change is made to it, that change won't affect the object throughout the script.


// const manipulator = {Monster : "Johan liebert",Death_Note:"Light yagami",Another_Note : "Beyond birthday",Psycho_pass : "Makashima_Shgo",ChainSawMan : "Makima"}; 
// const manipulator1 = manipulator; 
// console.log(typeof(manipulator)); 
// console.log(manipulator); 
// console.log("After adding another property,the object will be"); 
// manipulator.the20thCentuaryBoy = "Friend";   
// manipulator1.Death_Note = "Kira" 
// console.log(manipulator1); 
// console.log(manipulator);  // here we can see that the changes in manipulator1 object has affected the original object that is manipulator. 



// // 2] using new keyword: 
// // -> The following example create a new JavaScript object using new Object(), and then adds 4 properties:
// const Character = function() {
//     this.first = "LawLite"; 
//     this.second = "LightYagami"; 
//     this.third = "Mellow"; 
//     this.fourth = "Near"; 
//     this.fifth = "MisaAmane"; 
// }

// const Death_Note = new Character(); 
// const Death_Note2 = new Character();  
// console.log(Death_Note)
// console.log("After")
// Death_Note.first = "L" 
// console.log(Death_Note) 
// console.log(Death_Note2) // here we can simply depic that in constructor only one object attribute has changed. 


// javascript object's are mutable: 
//      Objects are mutable: They are addressed by reference, not by value.
//      const x = person;  // Will not create a copy of person. 



/************************Javascript object properties************************************* */
// Properties are the values associated with a JavaScript object.
// since, javascript objects is collection of unordered properties. 
// Properties can usually be changed, added, and deleted, but some are read only.
/*
The syntax for accessing the property of an object is:

objectName.property      // person.age -----> dot property accessor 
                         // You can use the dot property accessor in a chain to access deeper properties: object.prop1.prop2. 
or
objectName["property"]   // person["age"]

or
objectName[expression]   // x = 
"age"; person[x]
*/

// 1] deleting property: 


// const person = {
//   firstName: "Johan",
//   lastName: "liebert",
//   age: 50,
//   eyeColor: "blue"
// };
// console.log("Before deleting",person)
// delete person.age;
// console.log("After deleting",person)
// person.age = 20; 
// console.log("Again ",person)
// The delete keyword deletes both the value of the property and the property itself.

// After deletion, the property cannot be used before it is added back again.

// The delete operator is designed to be used on object properties. It has no effect on variables or functions.

// The delete operator should not be used on predefined JavaScript object properties. It can crash your application.


/************************Javascript object methoods************************************* */
//JavaScript methods are actions that can be performed on objects.
// A JavaScript method is a property containing a function definition.
// Accessing Object Methods
// You access an object method with the following syntax:
// objectName.methodName()
// You will typically describe fullName() as a method of the person object, and fullName as a property.
// The fullName property will execute (as a function) when it is invoked with ().
// This example accesses the fullName() method of a person object:

/*
objectName.methodName()
You will typically describe fullName() as a method of the person object, and fullName as a property.

The fullName property will execute (as a function) when it is invoked with ().

*/


/****************************Object display ******************************/
// Displaying a JavaScript object will output [object Object].
//Displaying Object Properties: 
/*
// directly accessing the properties of the object. 
const person = {
  name: "John",
  age: 30,
  city: "New York"
};

document.getElementById("demo").innerHTML =
person.name + "," + person.age + "," + person.city;

*/

/*
const person = {
  name: "John",
  age: 30,
  city: "New York"
};

let txt = "";
for (let x in person) {
txt += person[x] + " ";
};

document.getElementById("demo").innerHTML = txt; // using for loop 

*/

/*
const person = {
  name: "John",
  age: 30,
  city: "New York"
};

const myArray = Object.values(person);
document.getElementById("demo").innerHTML = myArray;
*/

// using stringify: 
// const person = {
//   name: "John",
//   age: 30,
//   city: "New York"
// };

// let myString = JSON.stringify(person);


/**********************************Javascript Object accessors **************************/ 
// Getters and setters allow you to define Object Accessors (Computed Properties).
// e.g, 

// getter example: 
// const person = {name:'sairaj',passion:'engineer of new world',another_name:'the coder kira 12',
//                 get id(){
//                     return "my name is" + this.name+" "+this.passion + " " + this.another_name; 
//                 }}
// console.log(person.id); 



// This example uses a lang property to set the value of the language property.
// const person = {name:'sairaj',passion:'engineer of new world',another_name:'the coder kira 12',
//                 set id(lang){
//                      this.name = 'sairaj'; 
//                 }}

// console.log(person.id); 
/*
Example 1 access fullName as a function: person.fullName().

Example 2 access fullName as a property: person.fullName.

The second example provides a simpler syntax.
*/

// Data Quality
/*
JavaScript can secure better data quality when using getters and setters.
Using the lang property, in this example, returns the value of the language property in upper case:

// we can get and set the property to the upper case independent of the user input by making the changes in following 2 lines: 
// for get fucntion: 
return this.language.toUpperCase(); 

// for set function: 
this.language = this.lang.toUpperCase(); 
*/

/*
Why Using Getters and Setters?
It gives simpler syntax
It allows equal syntax for properties and methods
It can secure better data quality
It is useful for doing things behind-the-scenes
*/

// Object.defineProperty()
// The Object.defineProperty() method can also be used to add Getters and Setters:

// Define object
// const obj = {counter : 0};

// // Define setters and getters
// Object.defineProperty(obj, "reset", {
//   get : function () {this.counter = 0;}
// });
// Object.defineProperty(obj, "increment", {
//   get : function () {this.counter++;}
// });
// Object.defineProperty(obj, "decrement", {
//   get : function () {this.counter--;}
// });
// Object.defineProperty(obj, "add", {
//   set : function (value) {this.counter += value;}
// });
// Object.defineProperty(obj, "subtract", {
//   set : function (value) {this.counter -= value;}
// });

// // Play with the counter:
// obj.reset;
// obj.add = 5;
// obj.subtract = 1;
// obj.increment;
// obj.decrement;

// console.log(obj)


/*************************Javascript Constructors ***********************************************/
// The examples from the previous chapters are limited. They only create single objects.
// Sometimes we need a "blueprint" for creating many objects of the same "type".
// The way to create an "object type", is to use an object constructor function.
// In the example above, function Person() is an object constructor function.
// Objects of the same type are created by calling the constructor function with the new keyword:

// function Person(name,sirname,age,colour){
//     this.name = name; 
//     this.sirname = sirname; 
//     this.age = age; 
//     this.colour = colour; 
// }

// const myFather = new Person("John", "Doe", 50, "blue");
// const myMother = new Person("Sally", "Rally", 48, "green");

// // let us add the property in existing object
// myFather.nationality = 'indian' 

// // let us now add the methood 
// myFather.intro = function(){
//     return this.name + " " + this.age + " "+this.colour; 
// }
// console.log(myFather.intro) 

// you cannot add the new property to the constructor. you can add new property only to the new object. 
// You cannot add a new method to an object constructor the same way you add a new method to an existing object.it is must be done inside the constructor function. 




/*****************************Javascript object prototypes ********************************************/
// The Object.prototype object has many built-in methods and properties such as toString(), valueOf(), etc. 
// JavaScript is a prototype-based language. 
// Whenever we create a function using JavaScript, the JavaScript engine adds a prototype property inside a function. 
// The prototype property is an object where we can attach methods and properties in a prototype object, which enables all the other objects to inherit these methods and properties.  


// Object is an built in constructor from which other objects are inheriting. 
function myDetails(name,job,DOB){
    this.name = name; 
    this.job = job; 
    this.DOB = DOB; 
}

const student = {  name1 :'sairaj', age:'20',passion:'engineer'}; 
console.log(student); 
console.log(myDetails.prototype); 
// editing the object prototype. 
Object.prototype.getName = function(){ // this line will add this methood in Object prototype 
     return this.name; 
}

myDetails.prototype.getName = function(){ // this will add the methood in myDetails prototype. 
    return this.name; 
}
const johan = new myDetails('johan',20,'economics');  
console.log(johan); 


// methoods and description: 
// hasOwnProperty(): It will return a boolean indicating whether an object contains the specified property as a direct property of that object and not inherited through the prototype chain. 

console.log(myDetails.prototype.hasOwnProperty(name1)); 


// isPrototypeOf(): It will return a boolean indicating whether the specified object is in the prototype chain of the object, this method is called upon. 
// propertyIsEnumerable(): It will return a boolean that indicates whether the specified property is enumerable or not.
// toLocaleString(): It will return the string in the local format.
// toString(): It will return the string.
// valueOf() :It will return the primitive value of the specified object.


// prototype inheritance: 
// The Object.prototype is on the top of the prototype inheritance chain:
// Date objects, Array objects, and Person objects inherit from Object.prototype

// javascript iterators: 
// The iterator protocol defines how to produce a sequence of values from an object.
// An object becomes an iterator when it implements a next() method.
// The next() method must return an object with two properties:

// value (the next value)
// done (true or false)
/*	
true if the iterator has completed
false if the iterator has produced a new value
*/

/*
Object	                                            Map
Not directly iterable	                            Directly iterable
Do not have a size   property	                    Have a size property
Keys must be Strings (or Symbols)	                Keys can be any datatype
Keys are not well ordered	                        Keys are ordered by insertion
Have default keys	                                Do not have default keys
*/

// const manipulator = {name:"Johan",lastName:"Liebert",Age:"20"}; 
// const manipulator = {
//   name: "Johan",
//   lastName : "Liebert",
//   Age       : 20,
//   name : function() {
//     return this.name + " " + this.lastName;
//   }
// };
// console.log(manipulator) 
// document.write("<br>") 
// // Accessing the object properties 

// // document.write("My favourite antagonist is : ",manipulator.name()) 
// document.write("<br>") 
// document.write("Age: ",manipulator.Age) 
// document.write("<br>") 
// document.write("Last Name: ",manipulator.lastName)
// document.write("<br>") 
// document.write("end") 
// // The name:values pairs in JavaScript objects are called properties:
// // Objects can also have methods.
// // Methods are actions that can be performed on objects.
// // Methods are stored in properties as function definitions.



// <========================================= Javascript events ======================================> 

// When JavaScript is used in HTML pages, JavaScript can "react" on these events 
/*Here are some examples of HTML events:

    An HTML web page has finished loading
    An HTML input field was changed
    An HTML button was clicked
 */

/*
e.g, 
    <button onclick="document.getElementById('demo').innerHTML = Date()">The time is?</button>
*/  

// JavaScript Numbers are Always 64-bit Floating Point 
// This format stores numbers in 64 bits, where the number (the fraction) is stored in bits 0 to 51, the exponent in bits 52 to 62, and the sign in bit 63: 
// The maximum number of decimals is 17. 
// let x = 0.2 + 0.1;
// alert(x); 
// alert((0.2 * 10 + 0.1 * 10) / 10); 

/*
WARNING:
    1] JavaScript uses the + operator for both addition and concatenation.
    2] Numbers are added. Strings are concatenated.
*/

// let x = "10";
// let y = "20";
// let z = x + y;
// console.log(z); 

// let x = 20; 
// let y = 20; 
// let z = x + y; 
// console.log(z); 

// let x = 10;
// let y = 20;
// let z = "30";
// let result = x + y + z;
// console.log(result) // 3030

//  let x = "10";
//  let y = 20;
//  let z = 30;
//  let result = x + y + z; //102030
//  console.log(result)

// let x = "1000";
// let y = "10";
// let z = x / y; // 100
// let z = x*y; // 10000
// let z = x-y; // 990 
// let z = x + y; // 10010
// console.log(z);

// let x = 100 / "Apple";
// console.log(x); 

// let x = 100 / "10";
// console.log(x); // 10
// let x = 100 / "Apple";
// console.log(isNaN(x)); //true 

//let x = NaN;
//let y = 5;
//let z = x + y;
//console.log(z) //NaN 

// let x = NaN;
// let y = "5";
// let z = x + y;
// console.log(z) // NaN5 
// console.log(typeof(x)) 
// console.log(typeof(NaN))


// Infinity (or -Infinity) is the value JavaScript will return if you calculate a number outside the largest possible number.

/* By default, JavaScript displays numbers as base 10 decimals.

But you can use the toString() method to output numbers from base 2 to base 36.

Hexadecimal is base 16. Decimal is base 10. Octal is base 8. Binary is base 2. */

// let num = 16; 
// console.log(num.toString(2)) // 10000 (number with base 2) using to string methood 
// console.log(num.toString(8)) // 20 (number with base 8) by using to string methood 

/*
<===========================================================================================================> 
Do not create Number objects.
The new keyword complicates the code and slows down execution speed.
*/



// BigInt: 
// JavaScript integers are only accurate up to 15 digit
//JavaScript BigInt variables are used to store big integer values that are too big to be represented by a normal JavaScript Number.

// let x = 1234567890123456789012345n; // declared as BigInt
// let y = BigInt(1234567890123456789012345) 
// console.log(typeof(y))
// console.log(typeof(x))

// let x = 9007199254740995n;
// let y = 9007199254740995n;
// let z = x * y;
// console.log(z); 
// console.log(typeof(z));


// let hex = 0x20000000000003n;
// let oct = 0o400000000000000003n
// let bin = 0b100000000000000000000000000000000000000000000000000011n
// console.log(hex) 
// console.log(oct)
// console.log(bin)


// to String methood 
// let x = 123;
// x.toString();
// (123).toString();
// (100 + 23).toString();
// console.log(x); 
// console.log(typeof(x.toString())) // string  (it is like the typecasting). 


// // toExponential methood: 
// let xb = 9.656;
// xb.toExponential(2);
// xb.toExponential(4);
// xb.toExponential(6);
// console.log(xb);
// console.log(xb.toExponential(2)); 
// console.log(xb.toExponential(4)); 

// let xc = 9.656;
// xc.toFixed(0);
// console.log(xc.toFixed(2));
// console.log(xc.toFixed(4));
// console.log(xc.toFixed(6));


// let xd = 9.656;
// xd.toPrecision();
// console.log(xd.toPrecision(2));
// console.log(xd.toPrecision(4));
// console.log(xd.toPrecision(6));

// // Number()	Returns a number converted from its argument.
// // parseFloat()	Parses its argument and returns a floating point number
// // parseInt()	Parses its argument and returns a whole number

// // The methods above are not number methods. They are global JavaScript methods.
// console.log(Number(true)); 
// console.log(Number("10  ")); 
// console.log(Number("John")); 
// console.log(Number(new Date("1970-01-01"))); 
// console.log(Number(new Date("1970-01-02"))); 
// parseInt("-10");
// parseInt("-10.33");
// parseInt("10");
// parseInt("10.33");
// console.log(parseInt("10 20 30"));
// console.log(parseInt("10 years")); 
// // Safe integers are all integers from -(253 - 1) to +(253 - 1).
// // This is safe: 9007199254740991. This is not safe: 9007199254740992. 

// const cars = [];
// cars[0]= "Saab";
// cars[1]= "Volvo";
// cars[2]= "BMW";
// cars[0] = "Kira"; 
// // cars = []; // error  
// cars[0] = ""; 
// console.log("sab changa si")


// // using new keyword  and declaring the array normally produces the same result. 
// const names = ["shreyash","abhishek","sairaj"] 
// console.log(names); 
// names[0] = "sanket"; 
// console.log(names); 

