console.log("functions") 
/* 
function name(parameter1, parameter2, parameter3) {
  // code to be executed
}
Function parameters are listed inside the parentheses () in the function definition.
Function arguments are the values received by the function when it is invoked.
*/

// JavaScript Function Syntax:
/* 

function name(parameter1, parameter2, parameter3) {
  // code to be executed
}

*/

/*Local Variables

Variables declared within a JavaScript function, become LOCAL to the function.

Local variables can only be accessed from within the function.
 */

// code here can NOT use carName
// const car = {type:"Fiat", model:"500", color:"white"};  
// // alert(car);
// console.log(car)
// It is a common practice to declare objects with the const keyword. 



// function invacation: 
// 1] function invacation meaning calling it. 
// e.g,
/*
function myFunction(a, b) {
  return a * b;
}
myFunction(10, 2);         
*/

// function calling using constructor: 
// This is a function constructor:
// function myFunction(arg1, arg2) {
//   this.firstName = arg1;
//   this.lastName  = arg2;
// }

// // This creates a new object
// const myObj = new myFunction("John", "Doe");

// // This will return "John"
// myObj.firstName;

// // function rest parameter: 
// function sum(...args) {
//   let sum = 0;
//   for (let arg of args) sum += arg;
//   return sum;
// }

// let x = sum(4, 9, 16, 25, 29, 100, 66, 77);


// function call() methood: 
// With the call() method, you can write a method that can be used on different objects.
// If a function is not a method of a JavaScript object, it is a function of the global object (see previous chapter).

// it is predefined methood. 
// it is used to invoke the method with an owner object and as an parameter. 

// const person1 = {
//   fullName: function(){
//       return this.firstName + " "+ this.lastName; 
//   }
// }

// const person = {
//   firstName: 'Sairaj', 
//   lastName: 'Rajput'
// }

// console.log(person1.fullName.call(person)); 


// call() function can accept arguments. 

// apply methood: 
// With the apply() method, you can write a method that can be used on different objects. 
// The apply methood takes the argument as an array while the call methood takes the arguments seperatly. 
// we can use it to find the maximum element in the array. 


const person = {
 fullName: function() {
    return this.firstName + " " + this.lastName;
  }
}

const person1 = {
  firstName: "Mary",
  lastName: "Doe"
}

// This will return "Mary Doe":
console.log(person.fullName.apply(person1));
console.log("sabse bada kon ?? ", Math.max.apply(null,[1,2,3,4,5,6,7,8,8,8,69])); 
console.log("sabse bada kon ?? ", Math.max(1,2,3,4,5,6,7,8,8,8,69)); 













