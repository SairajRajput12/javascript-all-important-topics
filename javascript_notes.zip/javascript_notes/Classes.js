/*
Syntax: 
class ClassName {
  constructor() { ... }
  method_1() { ... }
  method_2() { ... }
  method_3() { ... }
}
*/


class person{
    constructor(name,year){
        this.name = name;
        this.year = year;
    }

    age(){
        const data = new Date(); 
        return data.getFullYear() - this.year;  
    }
}


const n = new person('sairaj',2002); 
console.log(n.age()); 

// Classes inheritance: 
//      To create a class inheritance, use the extends keyword.
//      A class created with a class inheritance inherits all the methods from another class:

// class Car {
//   constructor(brand) {
//     this.carname = brand;
//   }
//   present() {
//     return 'I have a ' + this.carname;
//   }
// }

// class Model extends Car {
//   constructor(brand, mod) {
//     super(brand);
//     this.model = mod;
//   }
//   show() {
//     return this.present() + ', it is a ' + this.model;
//   }
// }

// let myCar = new Model("Ford", "Mustang");
// console.log(myCar.show()); 

// The super() method refers to the parent class.
// By calling the super() method in the constructor method, we call the parent's constructor method and gets access to the parent's properties and methods.

// static methoods: 
//      static class methoods are declared inside the class.
//      You cannot call a static method on an object, only on an object class.
class Car {
  constructor(name) {
    this.name = name;
  }
  static hello(x) {
    return "Hello " + x.name;
  }
}
const myCar1 = new Car("Ford");
console.log(Car.hello(myCar1));








