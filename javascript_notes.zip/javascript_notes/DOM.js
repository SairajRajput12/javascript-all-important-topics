// when the web page is created then Browser creates the Document Object Model of the page  
// The Document Object is constructed as a tree of the object. 
// With the object model, JavaScript gets all the power it needs to create dynamic HTML:

// JavaScript can change all the HTML elements in the page
// JavaScript can change all the HTML attributes in the page
// JavaScript can change all the CSS styles in the page
// JavaScript can remove existing HTML elements and attributes
// JavaScript can add new HTML elements and attributes
// JavaScript can react to all existing HTML events in the page
// JavaScript can create new HTML events in the page



// what is DOM ? 
// - defines the standard of accessing the element. 
// - Document Object Model (DOM) is a platform and language-neutral interface that allows programs and scripts to dynamically access and update the content, structure, and style of a document
// - What is the HTML DOM?
// The HTML DOM is a standard object model and programming interface for HTML. It defines:
// The HTML elements as objects
// The properties of all HTML elements
// The methods to access all HTML elements
// The events for all HTML elements
// In other words: The HTML DOM is a standard for how to get, change, add, or delete HTML elements.

// html DOM methood:  

// for finding the elements: 
/*
Method:	                                            Description
document.getElementById(id)	                        Find an element by element id
document.getElementsByTagName(name)	                Find elements by tag name
document.getElementsByClassName(name)	            Find elements by class name
*/

// for changing the html elements: 
/*
Method: 

Property	                            Description
element.innerHTML = new html content	Change the inner HTML of an element
element.attribute = new value	        Change the attribute value of an HTML element
element.style.property = new style	    Change the style of an HTML element
Method	Description
element.setAttribute(attribute, value)	Change the attribute value of an HTML element
*/


// Adding and Deleting Elements
/*
Method	                                    Description
document.createElement(element)	        Create an HTML element
document.removeChild(element)	        Remove an HTML element
document.appendChild(element)	        Add an HTML element
document.replaceChild(new, old)	        Replace an HTML element
document.write(text)	                Write into the HTML output stream
*/ 

// Adding event handler: 
// Method	                                                Description
// document.getElementById(id).onclick = function(){code}	Adding event handler code to an onclick event


// Property	Description	DOM
// document.anchors	                Returns all <a> elements that have a name attribute	1
// document.applets	                Deprecated	1
// document.baseURI	                Returns the absolute base URI of the document	3
// document.body	                Returns the <body> element	1
// document.cookie	                Returns the document's cookie	1
// document.doctype	                Returns the document's doctype	3
// document.documentElement	        Returns the <html> element	3
// document.documentMode	        Returns the mode used by the browser	3
// document.documentURI	            Returns the URI of the document	3
// document.domain	                Returns the domain name of the document server	1
// document.domConfig	            Obsolete.	3
// document.embeds	                Returns all <embed> elements	3
// document.forms	                Returns all <form> elements	1
// document.head	                Returns the <head> element	3
// document.images	                Returns all <img> elements	1
// document.implementation      	Returns the DOM implementation	3
// document.inputEncoding	        Returns the document's encoding (character set)	3
// document.lastModified	        Returns the date and time the document was updated	3
// document.links	                Returns all <area> and <a> elements that have a href attribute	1
// document.readyState	            Returns the (loading) status of the document	3
// document.referrer	            Returns the URI of the referrer (the linking document)	1
// document.scripts	                Returns all <script> elements	3
// document.strictError             Checking	Returns if error checking is enforced	3
// document.title	                Returns the <title> element	1
// document.URL     	            Returns the complete URL of the document	1




// finding element: 
/*
finding HTML elements by id
Finding HTML elements by tag name
Finding HTML elements by class name
Finding HTML elements by CSS selectors
Finding HTML elements by HTML object collections
*/

// using CSS selectors: 
// const x = document.querySelectorAll("p.intro");
// document.getElementById("demo").innerHTML ='The first paragraph (index 0) with class="intro" is: ' + x[0].innerHTML; 



// javascript events: 
/*
Examples of HTML events:

When a user clicks the mouse
When a web page has loaded
When an image has been loaded
When the mouse moves over an element
When an input field is changed
When an HTML form is submitted
When a user strokes a key

*/




















