// operator precedence: 
// Operator precedence describes the order in which operations are performed in an arithmetic expression.                 
// Multiplication (*) and division (/) have higher precedence than addition (+) and subtraction (-). 
// When many operations have the same precedence (like addition and subtraction or multiplication and division), they are computed from left to right:  
// document.write("100 + 50 * 3 :",100 + 50 * 3) 
// document.write("<br>"); 
// document.write("(100 + 50) * 3 :",(100 + 50) * 3); 
// document.write("<br>") 
// document.write("100 + 50 - 3 :",100 + 50 - 3); 
// document.write("<br>") 
// document.write(" 100 / 50 * 3 :", 100 / 50 * 3);

// let name = "sairaj"; 
// name += " "; 
// name += "rajput"; 
// document.write(name)


// let x = 10;
// x %= 5; 
// document.write("<br>")
// document.write(x)



// let x = 2; // 0010   --------> 2                                                            
// x <<= 3;   // 10000  --------> 16    // left shift increments the value.    

// let x = 512;  
// x >>= 6; // right shift shrinken the value. // 8
// document.write(x);

// The ??= Operator
// The Nullish coalescing assignment operator is used between two values.
// If the first value is undefined or null, the second value is assigned.
let x = 12;
x ??= 0;
document.write(x ??= 0)
document.write("<br>")
document.write("end")