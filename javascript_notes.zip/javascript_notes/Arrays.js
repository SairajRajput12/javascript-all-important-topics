console.log("This is kira"); 
// const name = ["kira","sairaj","light","yagami","justice","ka","choda"]; 
// console.log(name); 
// const cars = [];
// cars[0]= "Saab";
// cars[1]= "Volvo";
// cars[2]= "BMW"; 

// cars[0] = "sairaj"; 
// console.log(cars); 

/* 
********************Associative Arrays***************

Many programming languages support arrays with named indexes.

Arrays with named indexes are called associative arrays (or hashes).

JavaScript does not support arrays with named indexes.

In JavaScript, arrays always use numbered indexes.  
 */ 


/*
WARNING !!
If you use named indexes, JavaScript will redefine the array to an object.

After that, some array methods and properties will produce incorrect results.
 */

/*

In JavaScript, arrays use numbered indexes.  
In JavaScript, objects use named indexes.
 */
// const person = [];
// person["firstName"] = "John";
// person["lastName"] = "Doe";
// person["age"] = 46;
// person.length;     // Will return 0
// person[0];         // Will return undefined 

// Create an array with one element ???
// const points = new Array(40,100); 
// console.log(points.length); 


// The typeof operator returns object because a JavaScript array is an object. 
// const fruits = ["Banana", "Orange", "Apple", "Mango"];
// fruits.pop(); // deletes the element 
// fruits.push("Kel"); // pushes the element 

// const fruits = ["Banana", "Orange", "Apple", "Mango"];
// let length = fruits.push("Kiwi");
// console.log(length);

// 2] shift: it shifts the element of the array and reduces the length 
// const fruits = ["Banana", "Orange", "Apple", "Mango"];
// fruits.shift();
// console.log(fruits); // Array(3) [ "Orange", "Apple", "Mango" ] 
//   The shift() method returns the value that was "shifted out":
// const fruits = ["Banana", "Orange", "Apple", "Mango"];
// fruits.unshift("Lemon");
// console.log(fruits); 

/*

Array elements can be deleted using the JavaScript operator delete.

Using delete leaves undefined holes in the array.

Use pop() or shift() instead.
 */

// const phal = ["kel","santra","sapharchand","aamba"]; 
// const fp = phal.concat(fruits); 
// console.log(fp); 
/*
Flattening an array is the process of reducing the dimensionality of an array.
The flat() method creates a new array with sub-array elements concatenated to a specified depth.
*/

// let myArr = [[1,2],[3,4],[5,6]];
// const newArr = myArr.flat();
// console.log(newArr);  

// not working: 
// myArr.flat(); 
// console.log(myArr);


/* 
Splicing and Slicing Arrays

The splice() method adds new items to an array.

The slice() method slices out a piece of an array. 
*/ 

// const fruits = ["Banana", "Orange", "Apple", "Mango"];
// fruits.splice(2, 0, "Lemon", "Kiwi");
// console.log(fruits); 

// 0 ---------> number of the elment must be removed 
// 2 ---------> on which index these elements must be added 
// The rest of the parameters ("Lemon" , "Kiwi") define the new elements to be added. 

// const fruits = ["Banana", "Orange", "Apple", "Mango"];
// fruits.splice(2, 2, "Lemon", "Kiwi");
// console.log(fruits); 


/*

JavaScript Array slice()

The slice() method slices out a piece of an array into a new array.

This example slices out a part of an array starting from array element 1 ("Orange"):
 
*/

// const fruits = ["Banana", "Orange", "Lemon", "Apple", "Mango"];
// const citrus = fruits.slice(1); //  1 is the starting index which is included in new array 
// console.log(citrus); 

// array more methoods: 


//1]  using sort methood 

// const number = [2,4,1,3,6,5]; 
// console.log("after sorting :",number); 
// number.sort(); 
// console.log("after sorting :",number); 

// //2] reverse methood: 
// number.reverse(); 
// console.log("After reversing :",number); 

// /*By default, the sort() function sorts values as strings.

// This works well for strings ("Apple" comes before "Banana").

// However, if numbers are sorted as strings, "25" is bigger than "100", because "2" is bigger than "1".

// Because of this, the sort() method will produce incorrect result when sorting numbers.

// You can fix this by providing a compare function: */


// // assending order: 
// number.sort(function(a,b){return a-b}); 
// console.log(number); 

// // descending order: 
// number.sort(function(a,b){return b-a}); 
// console.log(number); 

// // Sorting an Array in Random Order 
// const points = [40, 100, 1, 5, 25, 10];
// points.sort(function(){return 0.5 - Math.random()}); 
// console.log(points); 

// /*************************Fisher yeits methood************************** */  
// /* 
// The most popular correct method, is called the Fisher Yates shuffle, and was introduced in data science as early as 1938!
// In JavaScript the method can be translated to this:
// */

// for (let i = points.length -1; i > 0; i--) {
//   let j = Math.floor(Math.random() * (i+1));
//   let k = points[i];
//   points[i] = points[j];
//   points[j] = k;
// }

// console.log(points); 

// *************************************** :JavaScript Array map(): ***************************************
/*

The map(): method creates a new array by performing a function on each array element.

The map(): method does not execute the function for array elements without values.

The map(): method does not change the original array. 

*/ 

// const number1 = [45,4,9,16,25];  
// const number2 = number1.map(myFunction); 
// function myFunction(value,index,array){
//     return 2*value;
// }
// console.log(number2); 


/***************************************JavaScript Array flatMap()********************************************/
// const myArr = [1,2,3,4,5,6]; 
// const newKira = myArr.flatMap((x) => 2*x); 
// console.log(newKira); 

/*
Array flatMap() method to JavaScript.

The flatMap() method first maps all elements of an array and then creates a new array by flattening the array. */

/********************************************JavaScript Array filter()*/ 
// const numbers = [45, 4, 9, 16, 25];
// const over18 = numbers.filter(myFunction);

// function myFunction(value, index, array) {
//   return value > 18;
// }

// console.log(over18); 

/*JavaScript Array reduce()
The reduce() method runs a function on each array element to produce (reduce it to) a single value.

The reduce() method works from left-to-right in the array. See also reduceRight().

The reduce() method does not reduce the original array.

 */

// programme for finding the sum: 
// const numbers = [45, 4, 9, 16, 25];
// let sum = numbers.reduce(myFunction);

// function myFunction(total, value, index, array) {
//   return total + value;
// }

// console.log(sum);  

/*

JavaScript Array reduceRight()
The reduceRight() method runs a function on each array element to produce (reduce it to) a single value.

The reduceRight() works from right-to-left in the array. See also reduce().

The reduceRight() method does not reduce the original array.
*/



// const numbers = [45, 4, 9, 16, 25];
// let sum = numbers.reduceRight(myFunction);

// function myFunction(total, value, index, array) {
//   return total + value;
// }

// console.log(sum); 

/*
JavaScript Array every()
The every() method checks if all array values pass a test. 
*/


const numbers = [45, 4, 9, 16, 25];
// let allOver18 = numbers.every(myFunction);
let allOver18 = numbers.some(myFunction); 
// let allOver18 = numbers.keys(myFunction); 
function myFunction(value, index, array) {
  return value > 18;
}

console.log(allOver18); // false; 

// array.indexOf(item, start) -------------> returns the index of an element 
let newm = numbers.keys(); 
console.log(newm); 



/*
Array method:
Array length 
Array toString()
Array pop()
Array push()
Array shift()
Array unshift()
Array join()
Array delete()
Array concat()
Array flat()
Array splice()
Array slice() 
*/


