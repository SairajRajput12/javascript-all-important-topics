/*
API stands for Application Programming Interface.

A Web API is an application programming interface for the Web.

A Browser API can extend the functionality of a web browser.

A Server API can extend the functionality of a web server.
*/


// web storage API: 

// simple syntax for storing and retriving data from web browser.

// The localStorage object provides access to a local storage for a particular Web Site. It allows you to store, read, add, modify, and delete data items for that domain.

// The data is stored with no expiration date, and will not be deleted when the browser is closed.

// The data will be available for days, weeks, and years.


// The setItem() Method: 

// The localStorage.setItem() method stores a data item in a storage.

// It takes a name and a value as parameters:

// The sessionStorage Object: 

// The sessionStorage object is identical to the localStorage object.

// The difference is that the sessionStorage object stores data for one session.

// The data is deleted when the browser is closed.


// The setItem() Method: 

// The sessionStorage.setItem() method stores a data item in a storage.

// It takes a name and a value as parameters:

// The getItem() Method
// The sessionStorage.getItem() method retrieves a data item from the storage.

// It takes a name as parameter:


/*
Storage Object Properties and Methods
Property/Method	                        Description
key(n)	                                Returns the name of the nth key in the storage
length	                                Returns the number of data items stored in the Storage object
getItem(keyname)	                    Returns the value of the specified key name
setItem(keyname, value)	                Adds a key to the storage, or updates a key value (if it already exists)
removeItem(keyname)	                    Removes that key from the storage
clear()	                                Empty all key out of the storage


Related Pages for Web Storage API

Property	                            Description
window.localStorage	                    Allows to save key/value pairs in a web browser. Stores the data with no expiration date
window.sessionStorage	                Allows to save key/value pairs in a web browser. Stores the data for one session

*/
/*
A Fetch API Example
The example below fetches a file and displays the content:

Example
fetch(file)
.then(x => x.text())
.then(y => myDisplay(y));
Since Fetch is based on async and await, the example above might be easier to understand like this:

Example
async function getText(file) {
  let x = await fetch(file);
  let y = await x.text();
  myDisplay(y);
}
Or even better: Use understandable names instead of x and y:

Example
async function getText(file) {
  let myObject = await fetch(file);
  let myText = await myObject.text();
  myDisplay(myText);

*/


// function showPosition(position) {
//   let latlon = position.coords.latitude + "," + position.coords.longitude;

//   let img_url = "https://maps.googleapis.com/maps/api/staticmap?center=
//   "+latlon+"&zoom=14&size=400x300&sensor=false&key=YOUR_KEY";

//   document.getElementById("mapholder").innerHTML = "<img src='"+img_url+"'>";
// }

/*

Property	                                Returns
coords.latitude	                    The latitude as a decimal number (always returned)
coords.longitude	                The longitude as a decimal number (always returned)
coords.accuracy	                    The accuracy of position (always returned)
coords.altitude	                    The altitude in meters above the mean sea level (returned if available)
coords.altitudeAccuracy	            The altitude accuracy of position (returned if available)
coords.heading	                    The heading as degrees clockwise from North (returned if available)
coords.speed	                    The speed in meters per second (returned if available)
timestamp	                        The date/time of the response (returned if available)


*/





