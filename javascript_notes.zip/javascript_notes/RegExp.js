/*  

    <h2>Regular expression</h2> 
    <ul>
    <li><h3>It is an expression that forms the search pattern</h3></li> 
    <li><h3>It is used in text search and text replacement operation</h3></li> 
    <li><h3>A regular expression can be a single character, or a more complicated pattern.</h3></li> 
    <li><h3>When you search for data in a text, you can use this search pattern to describe what you are searching for.</h3></li> 
    <li><h3>Regular expressions can be used to perform all types of text search and text replace operations.</h3></li>
    </ul>


    <h3>Syntax</h3> 
    <h3>/pattern/modifiers;</h3> 
    <h3>e.g, /w3schools/i;</h3> 
    <!-- // here w3schools is a pattern while i is an modifier.  --> 

 */

// Using String Methods
/*
let text = "Visit W3Schools!";
let n = text.search("W3Schools");
document.getElementById('demo').innerHTML = n; 
*/ 


// Use a regular expression to do a case-insensitive search for "w3schools" in a string:
/*
let text = "Visit W3Schools!";
let n = text.search(/w3school/i);
document.getElementById('demo').innerHTML = n; 
*/ 

/* 
Regular expression arguments (instead of string arguments) can be used in the methods above.
Regular expressions can make your search much more powerful (case insensitive for example).
 */


// replacing the string:  
// let text1 = "Sairaj is the best coder" 
// let result = text1.replace("best","Goat"); 
// console.log(result); 


// regular expression modifiers 
// 1] i ------------> case insensitive operations
// 2] g ------------> finds golbal match 
// 3] m ------------> performs multiline match 


// let textg = "Is this all there is?";
// let result3 = textg.match(/is/g);
// console.log(result3); 


// let textm = "\nIs th\nis it?";
// let result3 = textm.match(/^is/m);
// console.log(result3); 

/*
Regular expression modifiers:

Modifier	                 Description	
i	                 Perform case-insensitive matching	
g	                 Perform a global match (find all matches rather than stopping after the first match)	
m	                 Perform multiline matching



*/
/*
Expression	Description	Try it
[abc]	Find any of the characters between the brackets	
[0-9]	Find any of the digits between the brackets	
(x|y)	Find any of the alternatives separated with 
*/ 

let text2 = "re, green, red, green, gren, gr, blue, yellow";
let resulto = text2.match(/(red|green)/g);
console.log("result is :",resulto); 

let text3 = "123456sairaj7890isbest" 
let resulto1 = text3.match(/([0-9])/g); 
console.log("Result for digit is getting :", resulto1); 


// metacharacters: character with sepcial meaning. 
let text4 = "I am sure 100% that all mens are brave"; 
let resulto2 = text4.match(/\d/g);  
console.log(resulto2); 

// go for the white spaces/ 

let text5 = "Is this all there is?";
let resulti = text5.match(/\s/g);
console.log(resulti)

// finds the result at the start of the word 

let text6 = "HELLO, LOOK AT YOU!"; 
let resulti1 = text6.search(/\bLO/);
console.log(resulti1) 

// finds the result at the end of the word

let text7 = "HELLO, LOOK AT YOU!"; 
let resulti2 = text7.search(/LO\b/);
console.log(resulti2) 


// Find the Unicode character specified by the hexadecimal number xxxx	
let text8 = "Visit W3Schools. Hello World!"; 
let resulti3 = text8.match(/\u0057/g);
console.log(resulti3); 

// Quantifiers define quantities:

/*
Quantifier	        Description	
n+	                Matches any string that contains at least one n
n*	                Matches any string that contains zero or more occurrences of n
n?	                Matches any string that contains zero or one occurrences of n
*/ 

/*
Using test()
The test() method is a RegExp expression method.

It searches a string for a pattern, and returns true or false, depending on the result.

The following example searches a string for the character "e":
*/ 

/*
Using exec()
The exec() method is a RegExp expression method.

It searches a string for a specified pattern, and returns the found text as an object.

If no match is found, it returns an empty (null) object.

The following example searches a string for the character "e":
*/ 

// const obj = /e/.exec("The best things in life are free!");
// console.log("Found " + obj[0] + " in position " + obj.index + " in the text: " + obj.input); 









