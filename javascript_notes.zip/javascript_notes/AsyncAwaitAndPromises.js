// this is a secial syntax to work with the promisses in javascript. 
// A function made async by using async keyword in javascript. 
// what is promises? 
/*
    1] it is promise of code execution. 
    2] resolve/reject. 
    3] solution to the call back hell is promise. 
    4] code is either executes or failes in both cases will be notified. 
*/

// syntax: 
// let promise = new Promise(function(resolve,reject))
// let promise = new Promise(function(resolve,reject){
//         // alert('I am an alert in promise') 
//         alert('hello') 
//         resolve(56)
// })

// console.log('hello')

// setTimeout(function(){console.log('hello in 2 sec :')},2000) // displayed at the end of the other execution 
// // set timeout is asynchronous in nature. 
// console.log('my name is : ' + 'John')
// console.log(promise) 


// why use promise: Parllel execution. 
// fetch google.com homepage: => console.log(homepage done) 
// fetch API 
// fetch pictures from server. 
// print downloading. 
// Rest of the script 

// promise .then() and .catch() method: 
// let p1 = new Promise((resolve,reject) => {
//     console.log('promise is pending'); 
    
//     setTimeout(() => {
//         console.log('I am a promise and i am fullfilled')  
//         resolve(true) 
//         // reject(new Error("I am an error"))
//     },5000); 
// })

// let p2 = new Promise((resolve,reject) => {
//     console.log('promise is pending'); 
    
//     setTimeout(() => {
//         console.log('I am a promise and i am rejected')  
//         // resolve(true) 
//         reject(new Error("I am an error"))
//     },5000); 
// })

// p1.then((value)=>{
//     console.log("p1 is fullfilled.Gaya tata bay bay. khatam. Done"); // p1 zalyanantar. 
// },(error)=>{
//     console.log("error has occured.")
// })


// p2.catch((error) =>{
//     console.log("Some error has occured.The error has been purified") // this is used to resolve the error. 
// })


// p1 and p2 both will be executed parllely. 
// promise chaining .then() calls. 
// we can chain the promises and pass them one by one. 
// - the idea is to pass through the chain of .then() handling. 
// - initial promise resolves in t seconds. 
// - the next .then() handler is called which returns the new promise. 
// - the next .then() is result of the previous and it keeps going on. 


// let p1 = new Promise((resolve,request) =>{
//     setTimeout(() => {
//         console.log("resolve after 2 sec"); 
//         resolve(56); 
//     },5000)
// })

// p1.then((value) => {
//     console.log('resolved after 2 seconds');
//     let p2 = new Promise((resolve,request) => {
//             setTimeout(() =>{
//                 resolve("promise 2");  
//             },3000) 
//     })
//     return p2; 
// },(error) => {
//     console.log("error has occured."); 
// }).then((value) => {
//     console.log("We are done !"); 
//     return 2; 
// }).then((value) => {
//     console.log("Now we are pakka done")// call back hell
// })


// attaching multiple handler to single promise: 
// le1 = new Promise((resolve,reject) => {
//     setTimeout(() => { 
//         alert("I am L"); 
//         resolve(1); 
//     },2000); 
// })


// p1.then(() => {
//     console.log("Congrasulations promise now resolved"); 
// })

// p1.then(() => { 
//     alert("Hurray!")
//     return new Promise((resolve,reject) => { 
//         setTimeout(() => {
//             resolve(4) 
//         },6000); 
//     })
// }).then((value) => { 
//     console.log("Congrasulation problem is resolved"); 
// })
// let p1 = new Promise((resolve,reject) => {
//     setTimeout(() => { 
//         alert("I am L"); 
//         resolve(1); 
//     },2000); 
// })


// p1.then(() => {
//     console.log("Congrasulations promise now resolved"); 
// })

// p1.then(() => { 
//     alert("Hurray!")
//     return new Promise((resolve,reject) => { 
//         setTimeout(() => {
//             resolve(4) 
//         },6000); 
//     })
// }).then((value) => { 
//     console.log("Congrasulation problem is resolved"); 
// })


// Promise API: 
// these are the static methood given by promise class.  
// 1] promise.all(): 
// let p1 = new Promise((resolve,reject) => {
//     setTimeout(() => { 
//         // resolve("Value 1"); 
//         reject("error")
//     },1000); 
// }); 

// let p2 = new Promise((resolve,reject) => {
//     setTimeout(() => { 
//         resolve("Value 2"); 
//     },2000); 
// }); 


// let p3 = new Promise((resolve,reject) => {
//     setTimeout(() => { 
//         resolve("Value 3"); 
//     },3000); 
// }); 


// p1.then((value) => {
//     console.log(value); 
// })

// p2.then((value) => {
//     console.log(value); 
// })


// p3.then((value) => {
//     console.log(value); 
// })


// promise_all = Promise.all([p1,p2,p3]); 
// promise_all.then((value) => {
//     console.log(value); 
// })


// promise_all = Promise.race([p1,p2,p3]); 
// promise_all.then((value) => {
//     console.log(value); 
// })

// promise_all = Promise.any([p1,p2,p3]); // reject ke liye nahi rukega 
// promise_all = Promise.reject("Hey!");
// promise_all.then((value) => {
//     console.log(value); 
// })



// Async/ Await: 
//  - jindagi asan karegi 
//  - there is a special syntax to work with promises in javascript. 
//  - A function can be made async by using async keyword. 
//  Syntax: 
/*
    async function harry(){

    }
*/
// An async function always returns a promise. 
// code: 

async function harry(){ // async se promise return karega aisa sure hoga. 
    console.log("Aap dream 11 mein team bana lo!");  
    let DehliWheather = new Promise((resolve,reject) => { 
        setTimeout(() => {
            resolve("27 Deg")
        },2000); 
    })

    let BangloerWheather = new Promise((resolve,reject) => { 
        setTimeout(() => {
            resolve("21 Deg")
        },5000); 
    })

    // DehliWheather.then(alert)
    // BangloerWheather.then(alert)
    console.log("Fetching dehli wheather please wait......") 
    let dehli = await DehliWheather 
    console.log("Dehli wheather: " + dehli);  
    console.log("Fetching bangloer wheather please wait......") 
    let bangloer = await BangloerWheather  
    console.log("Bangloer wheather: " + bangloer);  
    return [dehli,bangloer]; 


}
const cherry = () =>{
    console.log("Hey i am cherry i am waiting")
}


let a  = harry()
a.then((value)=>{
    console.log(a); 
})

const main1 = async () => {
    console.log("Welcome to whether control")
    let a = await harry();
    let b = await cherry(); 
}
main1() 





































