// A Map holds key-value pairs where the keys can be any datatype.
// A Map remembers the original insertion order of the keys.

/*
Essential Map Methods
Method	Description

    new Map()	Creates a new Map
    set()	Sets the value for a key in a Map
    get()	Gets the value for a key in a Map
    delete()	Removes a Map element specified by the key
    has()	Returns true if a key exists in a Map
    forEach()	Calls a function for each key/value pair in a Map
    entries()	Returns an iterator with the [key, value] pairs in a Map
    Property	Description
    size	Returns the number of elements in a Map
 
*/ 

/*
How to Create a Map
You can create a JavaScript Map by: 
        Passing an Array to new Map()
        Create a Map and use Map.set()
*/

// 1] using new Map() methood: 
const m = new Map([[1,"Makima"],[2,"Denji"],[3,"Akki"],[4,"Power"]]); 
m.set("apples", 500);
m.set("bananas", 300);
m.set("oranges", 200); 

// The get() method gets the value of a key in a Map:
console.log(m.get("apples"));    // Returns 500

// The size property returns the number of elements in a Map: 
console.log(m.size); 

// The has() method returns true if a key exists in a Map:
console.log(m.has("apples"));// true 

m.delete("apples");
console.log(m.has("apples")); 


/*
// List all entries
let text = "";
fruits.forEach (function(value, key) {
  text += key + ' = ' + value;
})
*/

// The entries() Method
// The entries() method returns an iterator object with the [key, values] in a Map:
// List all entries
let text = "";
for (const x of m.entries()) {
  text += x;
}

/*

In JavaScript there are 5 different data types that can contain values:

string
number
boolean
object
function


There are 6 types of objects:

Object
Date
Array
String
Number
Boolean


And 2 data types that cannot contain values:

null
undefined

*/

/* 

The typeofoperator is not a variable. It is an operator. Operators ( + - * / ) do not have any data type.
But, the typeof operator always returns a string (containing the type of the operand).

*/

typeof "John"                 // Returns "string"
typeof 3.14                   // Returns "number"
typeof NaN                    // Returns "number"
typeof false                  // Returns "boolean"
typeof [1,2,3,4]              // Returns "object"
typeof {name:'John', age:34}  // Returns "object"
typeof new Date()             // Returns "object"
typeof function () {}         // Returns "function"
typeof myCar                  // Returns "undefined" *
typeof null                   // Returns "object"

/*
The constructor Property: 
The constructor property returns the constructor function for all JavaScript variables.
*/ 


