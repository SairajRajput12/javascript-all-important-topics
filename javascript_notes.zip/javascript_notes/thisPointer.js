/*
What is this?
In JavaScript, the this keyword refers to an object.

Which object depends on how this is being invoked (used or called).

The this keyword refers to different objects depending on how it is used:

-> In an object method, this refers to the object.
-> Alone, this refers to the global object.
-> In a function, this refers to the global object.
-> In a function, in strict mode, this is undefined.
-> In an event, this refers to the element that received the event.
-> Methods like call(), apply(), and bind() can refer this to any object.
-> this is not a variable. It is a keyword. You cannot change the value of this.

// this in a Method: 

*/


// const person = {first_name : "Johan",second_name : "Erick",third_name:"Den",
//                 fullName : function() {
//                     return this.firstName + " " + this.second_name+" "+this.third_name;
//                 }
// };


// this Alone: 
    // When used alone, this refers to the global object.
    // Because this is running in the global scope.
    // In a browser window the global object is [object Window]:
    // In strict mode, when used alone, this also refers to the global object:
    // this in a Function (Default)
    // In a function, the global object is the default binding for this.

// this in Event Handlers: 
    // In HTML event handlers, this refers to the HTML element that received the event:

// Object Method Binding
    // Object Method Binding


// Explicit Function Binding
    // The call() and apply() methods are predefined JavaScript methods.

    // They can both be used to call an object method with another object as argument.

/*
Function Borrowing
    With the bind() method, an object can borrow a method from another object.

    This example creates 2 objects (person and member).

    The member object borrows the fullname method from the person object:
*/





