// JavaScript accepts both double and single quotes:
// can change html,attribute values 
// JavaScript Can Change HTML Styles (CSS)
// JavaScript Can Hide HTML Element 
// JavaScript Can Show HTML Elements
console.log('this is tutorial 1:');
/*
document.write(5+6);
const name = 20; 
const nam = 'sairaj'; 
// document.write(name); 
// document.write(nam); 
console.log(name) 
console.log(nam)
console.log((5 + 6) * 10)
console.log("sai"+ "raj")
console.log("1"+"2")
*/
/*

4 Ways to Declare a JavaScript Variable:

    Using var
    Using let
    Using const
    Using nothing

*/


// using var: 
/*
var c = 5; 
var d = 6; 
var e = c + d; 
console.log(e)
var c = 7; 
console.log(c)
*/ 

// using let:
/*
let nae = "name"; 
console.log(nae); 
nae = "sairaj";
console.log(nae); 
// let nae = "sairaj"; // syntax error will be displayed. 
*/ 
/*
const a = 4; 
const b = 5; 
const m = a + b; 
console.log(m);
*/

// const a = 6; 
// console.log(a)
// a = 10; 
// console.log(a)


// undeclared:
/*
const a = 90; 
console.log(a); 
x = 5;
y = 6;
x  = 8; 
y = 90; 
z = x + y;
console.log(z)
*/ 

/*
const price1 = 5;
const price2 = 6;
const total = price1 + price2;
console.log(total);
*/ 

/*
The let keyword was introduced in ES6 (2015).

Variables defined with let can not be redeclared.

Variables defined with let must be declared before use.

Variables defined with let have block scope.
*/

//  demonstration with "let" variable: 
/*
let name = "sai";  // no error will be thrown
console.log(name); // empty string will be written
{
    let name  = "sairaj"; 
    console.log(name); 
}
// let name = "sai";  // error will be occuered
console.log(name); // empty string will be written
*/ 

// demonstration with "var" variable: 
// {
//     var naam = "sairaj"; 
// }
// console.log(naam); // can be accesed outside the block. 


// var x = 10;
// // Here x is 10
// console.log(x);
// {
//     var x = 2;
//     /*
//         So, in summary, the memory allocated for the variable naam will be freed at the end of the program execution or when the function that encloses the block completes execution.
//     */
//     // Here x is 2
// }

// console.log(x)
// Here x is 2 

// var x = 3; 
// {
//     let x = 5; 
//     console.log(x); 
// }

// {
//     let x = 9; 
//     console.log(x); 
// }


// // Redeclaring a variable with let, in another block, IS allowed: 
// let name = "sairaj"; 
// {
//     let name = "johan"; 
//     console.log("inside the block:",name); 
// }
// console.log("Outside the block:",name);
// console.log(x);


/* 
Variables defined with var are hoisted to the top and can be initialized at any time.
Meaning: You can use the variable before it is declared:
*/

/*
// valid: in case of this variable: 
carName = "Aulto"; 
var carName; 
console.log(carName); 
*/ 


// JavaScript const variables must be assigned a value when they are declared:
// const PI = 3.141592653589793;
// PI = 3.14;      // This will give an error
// PI = PI + 10;   // This will also give an error 
// console.log(PI); 


/* 
// const variable: 

When to use JavaScript const?

Always declare a variable with const when you know that the value should not be changed.

Use const when you declare:

    A new Array
    A new Object
    A new Function
    A new RegExp
*/ 

// Constant Objects and Arrays: 
// Constant Arrays
// You can change the elements of a constant array:

// const array = ["johan","light","kira","makashima"]; 
// console.log(array);  
// array[1] = "kira";
// array[2] = "friend";  
// console.log(array);
// array.push("makima"); 
// {
//     const array = ["johan","light","kira","makashima"];  
//     console.log("Inside the block :",array); 
// }
// console.log("Outside the block :",array); 

// monster = "Johan"; 
// const monster;  // not allowed 
// var monster; 
// console.log(monster);  
// let x = 5;
// let z = x ** 2;
// console.log(z) // 25 
// console.log(Math.pow(x,2)); // 25


console.log("End......");




