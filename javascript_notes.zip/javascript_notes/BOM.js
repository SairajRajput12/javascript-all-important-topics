/*
window.open() - open a new window
window.close() - close the current window
window.moveTo() - move the current window
window.resizeTo() - resize the current window


The window.screen object can be written without the window prefix.

Properties:

screen.width
screen.height
screen.availWidth
screen.availHeight
screen.colorDepth
screen.pixelDepth


The screen.width property returns the width of the visitor's screen in pixels.

The screen.height property returns the height of the visitor's screen in pixels.

The screen.availWidth property returns the width of the visitor's screen, in pixels, minus interface features like the Windows Taskbar.

The screen.availHeight property returns the height of the visitor's screen, in pixels, minus interface features like the Windows Taskbar.

The screen.colorDepth property returns the number of bits used to display one color.

All modern computers use 24 bit or 32 bit hardware for color resolution:

24 bits =      16,777,216 different "True Colors"
32 bits = 4,294,967,296 different "Deep Colors"
Older computers used 16 bits: 65,536 different "High Colors" resolution.

Very old computers, and old cell phones used 8 bits: 256 different "VGA colors".The screen.pixelDepth property returns the pixel depth of the screen.


The window.location object can be written without the window prefix.

Some examples:

window.location.href returns the href (URL) of the current page
window.location.hostname returns the domain name of the web host
window.location.pathname returns the path and filename of the current page
window.location.protocol returns the web protocol used (http: or https:)
window.location.assign() loads a new document


function newDoc() {
  window.location.assign("https://www.w3schools.com")
}


function goBack() {
  window.history.back() // it go to last page
}

function goForward() {
  window.history.forward() // it go for next page. 
}

Window Navigator
The window.navigator object can be written without the window prefix.

Some examples:

    navigator.cookieEnabled
    navigator.appCodeName
    navigator.platform
    navigator.appName

The Browser Engine:
    The product property returns the product name of the browser engine:

The Browser Version
    The appVersion property returns version information about the browser:

The Browser Agent
    The userAgent property returns the user-agent header sent by the browser to the server:

The Browser Language
    The language property returns the browser's language

Is The Browser Online?
    The onLine property returns true if the browser is online:

Is Java Enabled?
    The javaEnabled() method returns true if Java is enabled:



*/




let person = prompt("please enter your name","Sairaj rajput")
let text; 
if(person == null || person == ""){
    text = "User cancelled the prompt"
}

else{
    text = "Hello "+ person + "! How are you today ??"
}


alert(text)

/*
what are cookies ??
-> 
Cookies are data, stored in small text files, on your computer.

When a web server has sent a web page to a browser, the connection is shut down, and the server forgets everything about the user.

Cookies were invented to solve the problem "how to remember information about the user":

When a user visits a web page, his/her name can be stored in a cookie.
Next time the user visits the page, the cookie "remembers" his/her name.

function setCookie(cname, cvalue, exdays) {
  const d = new Date();
  d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
  let expires = "expires="+d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
  let name = cname + "=";
  let ca = document.cookie.split(';');
  for(let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

function checkCookie() {
  let user = getCookie("username");
  if (user != "") {
    alert("Welcome again " + user);
  } else {
    user = prompt("Please enter your name:", "");
    if (user != "" && user != null) {
      setCookie("username", user, 365);
    }
  }
}

*/
