console.log("this is tutorial number 1: AJAX tutorial")
/*


What is synchrnous and asynchrnous ??
-> In synchrnous, when a client makes a request to server he has to wait unti he gets the response which means synchrnous call blocks the client until the operations completes. 
-> In aynchrnous, when a client makes a request to serber he does not have to wait until he gets the response which means the asynchrnous call does not blocks the client until operation completes. 
-> He is free to do other activities. 




AJAX is a developer's dream, because you can:

Read data from a web server - after the page has loaded
Update a web page without reloading the page
Send data to a web server - in the background

*/
/*
what is AJAX ?? 
    -> it is not a programming language. 
    -> Asynchronous javascript and xml
    -> it uses the combination of: 
            A browser built-in XMLHttpRequest object (to request data from a web server)
            JavaScript and HTML DOM (to display or use the data) 
    -> helps in fetching the data asynchronously without existing page 
    -> no page reload/refresh 
    -> modern website use JSON instead or XML for data transfer. 
    -> XMLHttpsRequest is an API can be used by javascript, JScript,VBScript and other web browser scripting languaes to transfer and manipulate the data to and from webserver using HTTP, establishing an independent connection channel between client and server. 
    -> An object of XMLHttpRequest is used for asynchrnous communication between client and server. 
    -> it performs the following operations: 
        1] g

why use AJAX ?? 
    -> no page reload/refresh 
    -> better user expeience 
    -> saves network bandiwidth 
    -> very interactive

How AJAX works ??

    1. An event occurs in a web page (the page is loaded, a button is clicked)
    2. An XMLHttpRequest object is created by JavaScript
    3. The XMLHttpRequest object sends a request to a web server
    4. The server processes the request
    5. The server sends a response back to the web page
    6. The response is read by JavaScript
    7. Proper action (like page update) is performed by JavaScript
*/  

// Xttp response text property: 
/*vv
The responseText property returns the server response as a JavaScript string, and you can use it accordingly:


*/



// it uses XMLHttpRequest object also called xhr object.
// XMLHttpRequest kam kaise karti hai ?? 
let fetchBtn = document.getElementById('FetchBtn')
fetchBtn.addEventListener('click',buttonClickHandler) 

function buttonClickHandler(){
    // instantitate an xhr object 
    console.log('triggered...')
    const xhr = new XMLHttpRequest(); // creating the http request. 


    // open the object 
    // xhr.open('GET','https://jsonplaceholder.typicode.com/todos/1',true);  
    // third is asking about it is asynchronous or synchronous  

    xhr.open('POST','https://dummy.restapiexample.com/api/v1/create',true); // it fetches the data from the side. 
    xhr.getResponseHeader('Content-type','application/json'); // retyrbs the information about the header from the server 

    console.log(xhr.getAllResponseHeaders())
    /*
        XMLHttpRequest properties: 
        1] onreadystatechange: it defines a function to be called when the readystate property changes. 
        2] The onreadystatechange is called multiple timess during an xhr request. we explicitly ignore all the states other tgan ready state == 4, which means that the request is done. 
        3] readystate - this property returns the state an XMLHttpRequest client is in.An XHR client exists in one of the following states: 
            a] unset -> client request has created but open() has not called. 
            b] opened -> open() has invoked.during this state, the request heades can be set using the setRequestHeader() methos and send() method can be called. 
            c] HEADERS_RECIEVED: send() has been called and response headers have been recieved. 
            d] LOADING -> Response's body  is being recieved if responseType is "text" 
    */

    // what to do on progress ?? 
    xhr.onprogress = function(){
        console.log('On Progress'); 
    }

    // what to do when response is ready 
    xhr.onload = function(){ // it is the call back function. which is passed as a parameter to another function. 
    
    // it contains code that ready to execute when the response is ready. 

        if(this.status == 200){ // response ok
            console.log(this.responseText) 
        }
        else{
            console.log('some error occured ')
        }
        // console.log(this.responseText); 
    }

    // send this request/ 
    // xhr.send(); 
    params = `{"name":"test","salary":"123","age":"23"}` 
    xhr.send(params)// to send the request to the server.
    console.log('we are done !') // asynchrnous nature
}

let popBtn = document.getElementById('popBtn'); 
popBtn.addEventListener('click',popHandler); 

function popHandler(){
// instantitate an xhr object 
    console.log('triggered pop...')
    const xhr = new XMLHttpRequest(); 

    // open the object 
    // xhr.open('GET','https://jsonplaceholder.typicode.com/todos/1',true);  
    // third is asking about it is asynchronous or synchronous  

    xhr.open('GET','https://dummy.restapiexample.com/api/v1/employees',true); 

    // what to do on progress ?? 
    // what to do when response is ready 
    xhr.onload = function(){
        if(this.status == 200){ // response ok
            let obj = JSON.parse(this.responseText)
            console.log(obj)
            let list = document.getElementById('list'); 
            str = "";
            for(key in obj){
                str += `<li>${obj[key].employee_name}</li>`
            }
            list.innerHTML = str; 
        }
        else{
            console.log('some error occured ')
        }
        // console.log(this.responseText); 
    }

    // send this request/ 
    // xhr.send(); 
    xhr.send()
    console.log('we are fetcghin employees !') // asynchrnous nature
}



//  how to get the data from the server using load methood using ajax jquery. 
// the load() methood loads the data from the server and put it into the selected element. 
// $(selector).load(URL,data,callback); 





