// x = 16 + "Volvo"; 
// document.write(x); 
//let x = "16" + "Volvo";  
/*
Note
    When adding a number and a string, JavaScript will treat the number as a string.
*/
// let x = 16 + "Volvo";  
// document.write(x);

// let x = 16 + 4 + "Volvo"; 
// document.write("16 + 4 + Volvo : ",16 + 4 + "Volvo")
// document.write("<br>")
// document.write("Volvo + 16 + 4 :","Volvo" + 16 + 4)

// // JavaScript has dynamic types. This means that the same variable can be used to hold different data types: 
// // Single quote inside double quotes:
// let answer1 = "It's alright";

// // Single quotes inside double quotes:
// let answer2 = "He is called 'Johnny'";

// // Double quotes inside single quotes:
// let answer3 = 'He is called "Johnny"';

// console.log(answer1," ",answer2," ",answer3);

// // Exponential notation: 

// let y = 123e5;    // 12300000
// let z = 123e-5;   // 0.00123 

/*
Note: 

Most programming languages have many number types:

Whole numbers (integers):
byte (8-bit), short (16-bit), int (32-bit), long (64-bit)

Real numbers (floating-point):
float (32-bit), double (64-bit).

Javascript are always one type:
double (64-bit floating point).
*/
//let x = BigInt("123456789012345678901234567890"); 
//document.write(x); 
// const cars = ["Saab", "Volvo", "BMW"]; 
// cars[0] = "Johan"; 
// document.write(cars);
// const person = {firstName:"John", lastName:"Doe", age:50, eyeColor:"blue"};
// person[1] = "Liebert"; 
// document.write("The object is :",person[0]);
// console.log(person);
// console.log(typeof(person))

// Undefined: 



document.write("<br>")
document.write("end")